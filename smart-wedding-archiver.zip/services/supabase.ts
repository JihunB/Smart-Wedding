import { createClient } from '@supabase/supabase-js';

// NOTE: In a real environment, these are process.env.NEXT_PUBLIC_...
// For this generated demo, we assume they are provided in the environment or placeholder
const supabaseUrl = process.env.SUPABASE_URL || 'https://your-project.supabase.co';
const supabaseKey = process.env.SUPABASE_ANON_KEY || 'your-anon-key';

export const supabase = createClient(supabaseUrl, supabaseKey);
